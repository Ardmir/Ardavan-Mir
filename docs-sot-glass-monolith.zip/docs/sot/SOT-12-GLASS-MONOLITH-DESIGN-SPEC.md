# SOT-12 — "Glass Monolith" Design Spec

Version: 0.1
Last updated: 2026-06-14
Status: Active — Phase 1 pending
Related: D-010 (SOT-09), v0.4 (SOT-08)

## Source

Visual direction explored in Google Stitch ("The Glass Monolith"). Two reference
screenshots: a fullscreen overlay-nav state and an "INTELLIGENT SYSTEMS, DECODED"
hero state. Stitch is used as a VISUAL idea source only.

## Hard rule — copy

Take ONLY layout, style, typography, and behavior from the Stitch designs.
Take NONE of the copy. All text, positioning, contact details, and project
content stay exactly as confirmed in SOT-01/03/04 and as currently live on
ardavanmir.com.

DO NOT ship any of these fabricated Stitch strings:
- "specializing in high-fidelity data visualization and product architecture"
  (WRONG positioning — real positioning is enterprise SaaS, AI-native workflows,
  financial systems, IA, high-trust workflows)
- "London, UK — 51.5072 N" (WRONG — Ardavan is in Toronto)
- "(c) 2024" (WRONG year — use current year, dynamic)
- "READ.CV" link (defunct service — dead link, do not add)

Real hero copy stays as live: H1 "I design intelligent products that turn
financial complexity into confident action." + the confirmed descriptive subcopy.
Principle line "Make the system legible before making it smart." may be used as
a secondary line (it already appears in the Stitch ref and is SOT-approved).

## Visual language

Typography:
- High-contrast editorial SERIF for display (overlay nav items, italic accents).
- Thin geometric SANS for the oversized hero (all-caps, wide tracking).
- Monospace for technical chrome (labels, coordinates).
- Signature move: oversized all-caps hero with FILLED first word + OUTLINE/hollow
  stroke second word (Stitch showed "INTELLIGENT SYSTEMS," filled, "DECODED."
  outline). Adapt to real copy, not Stitch's words.

Palette (extends SOT-05; near-black, darker than current #0B0F10):
- Background near-absolute black (~#000000 to #07090A)
- Soft white text #F4F7F6
- Electric teal accent #31F5D4 (active/hover), used sparingly
- Existing muted #A8B3B0 for secondary

Chrome (decorative; all aria-hidden):
- "A / MIR" wordmark top-left; minimal nav top-right, teal active state
- Optional corner coordinate readouts, "LIVE SESSION" dot, footer metadata row
- Scope TBD (see open decisions)

Behavior:
- Phase 1: fullscreen OVERLAY NAV (big serif items numbered 01–04, CLOSE x).
  Keyboard accessible, focus-trapped, esc to close, aria-expanded.
- Phase 2 (optional): HORIZONTAL-SCROLL work section. Highest UX risk.
  Requires keyboard nav, vertical fallback on mobile, prefers-reduced-motion.

## Phased plan

Phase 1 — Re-skin existing vertical site in Glass Monolith language.
Keep vertical layout + all real copy. Fonts, hero type treatment, near-black
palette, overlay nav, minimal chrome. Ship + verify deploy.

Phase 2 — Horizontal-scroll work section, own branch, only after Phase 1 solid.

## Open decisions (confirm before Phase 1 build)

1. Typefaces: do we know the exact Stitch fonts? If not, use well-licensed
   equivalents via next/font (self-hosted), e.g. a high-contrast serif
   (Fraunces / similar) + a thin grotesque (light Inter / similar). Pick for
   performance + licensing, match existing next/font setup.
2. Chrome scope: full (coordinates + LIVE SESSION + footer metadata) or minimal
   (wordmark + nav + footer line only)?
3. Horizontal scroll: confirmed deferred to Phase 2.

## Accessibility (non-negotiable, per SOT-05)

One h1. Semantic sections. Overlay nav keyboard-operable + focus-trapped.
Decorative chrome aria-hidden. prefers-reduced-motion respected. WCAG AA
contrast (check thin sans on near-black — thin weights can fail contrast at
small sizes). No hover-only critical info. Mobile-first; no layout overflow.

## Tech constraints (per SOT-07 / actual repo)

Next.js App Router + Tailwind, static export (`output: "export"`,
images.unoptimized). Deploy = .github/workflows/deploy.yml on push to main
(pnpm; pushes touching workflows need SSH). Preserve public/CNAME
(www.ardavanmir.com) + .nojekyll. New fonts via next/font, self-hosted.
Work on a fresh branch off main; build locally (pnpm build) before PR; never
merge without a green build (merge auto-deploys).

## Pickup prompt for next session (Phase 1)

> Read docs/sot/SOT-12 and D-010 first; treat them as the spec. Start Phase 1 of
> the Glass Monolith re-skin. New branch off main (git checkout main && git pull
> && git checkout -b glass-monolith-phase-1). Re-skin the EXISTING vertical site:
> add the two display fonts via next/font, apply the oversized hero type
> treatment (filled + outline) to the REAL hero copy, shift to near-black palette,
> add the fullscreen overlay nav (keyboard accessible, focus-trapped), and the
> chrome scope we confirmed. Keep ALL existing copy and contact details unchanged.
> Do not introduce any Stitch copy. Keep one h1, respect prefers-reduced-motion,
> aria-hide decorative chrome. Then pnpm build, show me the diff + build result.
> Don't commit until I review.
